package com.modblocker;

import com.modblocker.command.ModBlockerCommand;
import com.modblocker.config.BlockRule;
import com.modblocker.config.ConfigManager;
import com.modblocker.config.ModBlockerConfig;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

public class ModBlocker implements ModInitializer {

    public static final String MOD_ID = "modblocker";
    public static final Logger LOGGER = LoggerFactory.getLogger("ModBlocker");

    @Override
    public void onInitialize() {
        ConfigManager.load();
        LOGGER.info("[ModBlocker] Loaded config from {}", ConfigManager.getConfigFile());

        syncServerPropertiesResourcePack();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                ModBlockerCommand.register(dispatcher));

        ServerPlayConnectionEvents.JOIN.register(this::onPlayerJoin);
    }

    private void onPlayerJoin(net.minecraft.server.network.ServerPlayNetworkHandler handler,
                               net.fabricmc.fabric.api.networking.v1.PacketSender sender,
                               net.minecraft.server.MinecraftServer server) {
        ModBlockerConfig cfg = ConfigManager.get();
        if (!cfg.enabled) {
            return;
        }

        ServerPlayerEntity player = handler.player;

        // Channels the connected client declared it can receive packets on. In practice this
        // is populated by every mod that registers its own networking, so the namespace of
        // each channel is a strong (though not 100% exhaustive - purely client-side/no-netcode
        // mods won't show up here) signal for "which mods does this client have".
        Set<Identifier> channels = ServerPlayNetworking.getSendable(player);

        if (cfg.logDetections) {
            LOGGER.info("[ModBlocker] {} joined with {} detected channel(s): {}",
                    player.getGameProfile().getName(), channels.size(), channels);
        }

        BlockRule matched = findMatch(cfg, channels);

        boolean shouldKick;
        String reason;

        if ("whitelist".equalsIgnoreCase(cfg.mode)) {
            shouldKick = (matched == null) && !channels.isEmpty();
            // If nothing matched a whitelist rule, boot them. (A totally vanilla client with
            // zero channels will also have nothing to match - decide if that's ok for your
            // server; by default we let bare-vanilla clients through since they can't be
            // running any of the mods you're worried about.)
            reason = "Your client does not match any approved mod on this server.";
        } else {
            shouldKick = matched != null;
            reason = (matched != null) ? matched.reason : "";
        }

        if (shouldKick) {
            String message = cfg.kickMessage.replace("%reason%", reason);
            handler.disconnect(Text.literal(message));
            LOGGER.info("[ModBlocker] Kicked {} - {}", player.getGameProfile().getName(), reason);
        }
    }

    private BlockRule findMatch(ModBlockerConfig cfg, Set<Identifier> channels) {
        for (Identifier channel : channels) {
            String namespace = channel.getNamespace();
            String full = channel.toString();
            for (BlockRule rule : cfg.rules) {
                if (ConfigManager.matches(rule, namespace, full)) {
                    return rule;
                }
            }
        }
        return null;
    }

    /**
     * Vanilla's dedicated server already fully supports requiring a resource pack and kicking
     * anyone who declines/fails it, via server.properties (resource-pack, resource-pack-sha1,
     * require-resource-pack, resource-pack-prompt). There is no reliable way for a mod to
     * detect resource packs a client already has installed - the protocol simply doesn't send
     * that information - so rather than reinventing (and likely breaking) that flow with
     * fragile custom packet code, this mod just keeps server.properties in sync with your
     * modblocker config so you only have to edit one file. This only takes effect on server
     * (re)start, since server.properties is read once at startup.
     */
    private void syncServerPropertiesResourcePack() {
        ModBlockerConfig cfg = ConfigManager.get();
        if (!cfg.requireServerResourcePack) {
            return;
        }
        Path propsPath = Path.of("server.properties");
        if (!Files.exists(propsPath)) {
            LOGGER.warn("[ModBlocker] requireServerResourcePack is true but server.properties "
                    + "was not found yet - skipping sync this run.");
            return;
        }
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(propsPath)) {
            props.load(in);
        } catch (IOException e) {
            LOGGER.warn("[ModBlocker] Could not read server.properties: {}", e.getMessage());
            return;
        }

        props.setProperty("require-resource-pack", "true");
        props.setProperty("resource-pack", cfg.resourcePackUrl == null ? "" : cfg.resourcePackUrl);
        props.setProperty("resource-pack-sha1", cfg.resourcePackSha1 == null ? "" : cfg.resourcePackSha1);
        props.setProperty("resource-pack-prompt", cfg.resourcePackKickMessage == null ? "" : cfg.resourcePackKickMessage);

        try (OutputStream out = Files.newOutputStream(propsPath)) {
            props.store(out, "Updated by ModBlocker - restart the server for this to take effect");
            LOGGER.info("[ModBlocker] Synced resource pack settings into server.properties. "
                    + "Restart the server once for this to take effect.");
        } catch (IOException e) {
            LOGGER.warn("[ModBlocker] Could not write server.properties: {}", e.getMessage());
        }
    }
}
