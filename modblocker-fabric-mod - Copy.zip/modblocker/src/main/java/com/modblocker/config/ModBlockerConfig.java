package com.modblocker.config;

import java.util.ArrayList;
import java.util.List;

public class ModBlockerConfig {

    /** Master on/off switch. */
    public boolean enabled = true;

    /**
     * "blacklist" (default): anyone matching a rule below is kicked.
     * "whitelist": ONLY players whose detected channels/brand match at least one rule are
     * allowed to join; everyone else is kicked. Use with care - most vanilla clients and
     * mods that don't use networking won't match anything.
     */
    public String mode = "blacklist";

    /** Message shown to the player on kick. %reason% is replaced with the matched rule's reason. */
    public String kickMessage = "You have been disconnected:\n%reason%";

    /** Log every join's detected channels to the server console/log. Handy for building rules. */
    public boolean logDetections = true;

    /**
     * If true, the server will require players to accept a server resource pack (configured
     * below) and kick anyone who declines or fails to download it. This is the closest thing
     * to "blocking a resource pack" that the Minecraft protocol actually allows - the server
     * cannot see what packs a client already has installed locally, only whether the client
     * accepted the pack the server sent it.
     */
    public boolean requireServerResourcePack = false;

    /** Direct download URL for the resource pack (must be publicly reachable by clients). */
    public String resourcePackUrl = "";

    /** SHA-1 hash of the resource pack zip. Leave blank to skip hash verification. */
    public String resourcePackSha1 = "";

    /** Message shown if the server pack is declined/failed and requireServerResourcePack is true. */
    public String resourcePackKickMessage = "You must accept the server resource pack to play here.";

    public List<BlockRule> rules = new ArrayList<>();

    public static ModBlockerConfig createDefault() {
        ModBlockerConfig cfg = new ModBlockerConfig();

        // A few examples so the generated file isn't empty - edit/remove these freely.
        cfg.rules.add(new BlockRule(BlockRule.Type.NAME, "xray",
                "X-ray / cheat-adjacent mods are not allowed."));
        cfg.rules.add(new BlockRule(BlockRule.Type.MODID, "wurst",
                "Cheat clients are not allowed."));
        cfg.rules.add(new BlockRule(BlockRule.Type.REGEX, "(?i)(freecam|baritone)",
                "Freecam/autominer mods are not allowed."));
        cfg.rules.add(new BlockRule(BlockRule.Type.LINK,
                "https://modrinth.com/mod/xaeros-minimap",
                "Minimap mods are not allowed on this server."));

        return cfg;
    }
}
