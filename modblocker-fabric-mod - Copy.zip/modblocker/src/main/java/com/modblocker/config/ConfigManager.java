package com.modblocker.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("modblocker");
    private static final Path CONFIG_FILE = CONFIG_DIR.resolve("config.json");

    private static ModBlockerConfig config = ModBlockerConfig.createDefault();

    private ConfigManager() {
    }

    public static ModBlockerConfig get() {
        return config;
    }

    public static synchronized void load() {
        try {
            Files.createDirectories(CONFIG_DIR);
            if (!Files.exists(CONFIG_FILE)) {
                save(ModBlockerConfig.createDefault());
            }
            try (Reader reader = Files.newBufferedReader(CONFIG_FILE, StandardCharsets.UTF_8)) {
                ModBlockerConfig loaded = GSON.fromJson(reader, ModBlockerConfig.class);
                config = (loaded != null) ? loaded : ModBlockerConfig.createDefault();
            }
        } catch (IOException e) {
            throw new RuntimeException("[ModBlocker] Failed to load config.json", e);
        }
    }

    public static synchronized void save(ModBlockerConfig toSave) {
        try {
            Files.createDirectories(CONFIG_DIR);
            try (Writer writer = Files.newBufferedWriter(CONFIG_FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(toSave, writer);
            }
            config = toSave;
        } catch (IOException e) {
            throw new RuntimeException("[ModBlocker] Failed to save config.json", e);
        }
    }

    public static synchronized void reload() {
        load();
    }

    public static Path getConfigFile() {
        return CONFIG_FILE;
    }

    /**
     * Checks a single detected channel namespace/full-id against one rule.
     */
    public static boolean matches(BlockRule rule, String namespace, String fullChannelId) {
        if (!rule.enabled || rule.value == null || rule.value.isBlank()) {
            return false;
        }
        String value = rule.value.trim();

        switch (rule.type) {
            case MODID:
                return namespace.equalsIgnoreCase(value) || value.equalsIgnoreCase(fullChannelId);
            case CHANNEL:
                return fullChannelId.equalsIgnoreCase(value);
            case NAME:
                return namespace.toLowerCase().contains(value.toLowerCase());
            case REGEX:
                try {
                    Pattern p = Pattern.compile(value);
                    return p.matcher(namespace).find() || p.matcher(fullChannelId).find();
                } catch (PatternSyntaxException e) {
                    return false;
                }
            case LINK:
                String slug = extractSlugFromLink(value);
                if (slug == null) {
                    return false;
                }
                return namespace.toLowerCase().contains(slug.toLowerCase())
                        || namespace.equalsIgnoreCase(slug.replace("-", ""));
            default:
                return false;
        }
    }

    /**
     * Best-effort extraction of a project slug/id out of a Modrinth or CurseForge URL, e.g.
     * "https://modrinth.com/mod/xaeros-minimap" -> "xaeros-minimap"
     * "https://www.curseforge.com/minecraft/mc-mods/xaeros-minimap" -> "xaeros-minimap"
     */
    public static String extractSlugFromLink(String link) {
        try {
            String cleaned = link.trim();
            if (cleaned.endsWith("/")) {
                cleaned = cleaned.substring(0, cleaned.length() - 1);
            }
            int q = cleaned.indexOf('?');
            if (q != -1) {
                cleaned = cleaned.substring(0, q);
            }
            String[] parts = cleaned.split("/");
            if (parts.length == 0) {
                return null;
            }
            return parts[parts.length - 1];
        } catch (Exception e) {
            return null;
        }
    }

    public static List<BlockRule> getRules() {
        return config.rules;
    }
}
