package com.modblocker.config;

/**
 * A single "thing to block" entry. You can specify it several different ways depending on
 * what's most convenient to you - a mod id, a plain name/keyword, a regex, an exact network
 * channel, or a link to the mod's Modrinth/CurseForge page (we extract the slug from the link
 * and match it like a name).
 */
public class BlockRule {

    public enum Type {
        /**
         * Exact match against a mod's channel namespace (roughly equivalent to its mod id),
         * e.g. "xaerominimap"
         */
        MODID,
        /**
         * Case-insensitive "contains" match against the channel namespace, e.g. "xray" would
         * match "xraymod", "betterxray", etc.
         */
        NAME,
        /**
         * Full Java regex, tested against every detected channel namespace and against the
         * full "namespace:path" channel id.
         */
        REGEX,
        /**
         * Exact match against a full channel identifier, e.g. "xaerominimap:main"
         */
        CHANNEL,
        /**
         * A Modrinth or CurseForge project URL. We pull the slug out of the URL and treat it
         * like a NAME match. This is purely a convenience - the underlying check is still
         * namespace-based, because the server has no way to "look up" a link at runtime.
         */
        LINK
    }

    public Type type = Type.NAME;
    public String value = "";
    public String reason = "This mod is not allowed on this server.";
    public boolean enabled = true;

    public BlockRule() {
    }

    public BlockRule(Type type, String value, String reason) {
        this.type = type;
        this.value = value;
        this.reason = reason;
    }
}
