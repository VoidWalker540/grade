package com.modblocker.command;

import com.mojang.brigadier.CommandDispatcher;
import com.modblocker.config.BlockRule;
import com.modblocker.config.ConfigManager;
import com.modblocker.config.ModBlockerConfig;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.Set;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class ModBlockerCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("modblocker")
                .requires(src -> src.hasPermissionLevel(3))
                .then(literal("reload").executes(ModBlockerCommand::reload))
                .then(literal("list").executes(ModBlockerCommand::list))
                .then(literal("inspect")
                        .then(argument("player", EntityArgumentType.player())
                                .executes(ModBlockerCommand::inspect)))
        );
    }

    private static int reload(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ConfigManager.reload();
        ctx.getSource().sendFeedback(() -> Text.literal("[ModBlocker] Config reloaded from "
                + ConfigManager.getConfigFile()), true);
        return 1;
    }

    private static int list(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        ModBlockerConfig cfg = ConfigManager.get();
        ctx.getSource().sendFeedback(() -> Text.literal("[ModBlocker] enabled=" + cfg.enabled
                + " mode=" + cfg.mode + " rules=" + cfg.rules.size()), false);
        int i = 1;
        for (BlockRule rule : cfg.rules) {
            final int idx = i++;
            ctx.getSource().sendFeedback(() -> Text.literal(
                    "  " + idx + ". [" + rule.type + "] " + rule.value
                            + (rule.enabled ? "" : " (disabled)") + " -> " + rule.reason), false);
        }
        return 1;
    }

    private static int inspect(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        Set<Identifier> channels = ServerPlayNetworking.getSendable(target);

        ctx.getSource().sendFeedback(() -> Text.literal("[ModBlocker] " + target.getGameProfile().getName()
                + " has " + channels.size() + " detected channel(s):"), false);
        for (Identifier channel : channels) {
            ctx.getSource().sendFeedback(() -> Text.literal("  - " + channel), false);
        }
        ctx.getSource().sendFeedback(() -> Text.literal(
                "Tip: the part before the ':' (the namespace) is usually the mod's id - "
                        + "use that with a \"modid\" or \"name\" rule in config.json."), false);
        return 1;
    }
}
