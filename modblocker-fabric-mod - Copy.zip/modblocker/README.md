# ModBlocker

A server-side Fabric mod for Minecraft **1.21.11** (Fabric Loader **0.19.2+**, Fabric API
**0.141.1+1.21.11**) that kicks players whose client is running mods you've blocklisted,
configurable through a single JSON file.

## Read this first: what it can and can't actually detect

Minecraft's network protocol was not designed for this, so it's worth being upfront:

- **Mods**: When a mod with any client-server networking loads, it registers a "channel"
  (basically `mod_id:something`) with the client, and the client tells the server which
  channels it supports as soon as it connects. This mod reads that list and matches it
  against your rules. This catches the large majority of mods people usually want to block
  (minimaps, freecam, cheat clients, x-ray-with-server-sync, etc.), **but it cannot see a
  mod that has zero networking code** (a few purely client-visual mods exist that never talk
  to the server at all). There is no protocol-level "send me your full mod list" handshake
  in vanilla Fabric, unlike Forge.
- **Resource packs**: There is genuinely no packet in the Minecraft protocol that lets a
  server ask "what resource packs do you have installed?" The server can only push its own
  pack to the client and see whether it was accepted or declined. So this mod does **not**
  (and no mod honestly can) detect "player has resource pack X" the same way it detects mods.
  What it does instead: it can require **your own** resource pack and have the vanilla server
  kick anyone who declines/fails it (see `requireServerResourcePack` below) — that's the
  closest real equivalent, and it's actually built into vanilla already.

## Building

1. Install a JDK 21.
2. `./gradlew build` (or `gradlew.bat build` on Windows) from this folder.
3. The compiled jar shows up in `build/libs/modblocker-1.0.0.jar`.
4. Drop it into your server's `mods/` folder, alongside Fabric API `0.141.1+1.21.11` (or newer
   for 1.21.11), running Fabric Loader 0.19.2+.

This project uses the standard Fabric example-mod Gradle template (Loom), so if you already
have a Java IDE with Gradle support (IntelliJ, VS Code), you can just open the folder and it
will set itself up, including a `genSources`-able local Minecraft source for reference.

> Note on mappings: this code targets the class/method names as documented for Fabric API
> `0.141.1+1.21.11` (`ServerPlayNetworking.getSendable(ServerPlayerEntity)`, etc.). If your
> local Yarn build names something slightly differently, your IDE's auto-import/quick-fix will
> point you to the renamed equivalent — the logic doesn't change.

## Config

First run generates `config/modblocker/config.json` on the server. Example:

```json
{
  "enabled": true,
  "mode": "blacklist",
  "kickMessage": "You have been disconnected:\n%reason%",
  "logDetections": true,
  "requireServerResourcePack": false,
  "resourcePackUrl": "",
  "resourcePackSha1": "",
  "resourcePackKickMessage": "You must accept the server resource pack to play here.",
  "rules": [
    { "type": "NAME",  "value": "xray",  "reason": "X-ray mods are not allowed.", "enabled": true },
    { "type": "MODID", "value": "wurst", "reason": "Cheat clients are not allowed.", "enabled": true },
    { "type": "REGEX", "value": "(?i)(freecam|baritone)", "reason": "Freecam/autominer mods are not allowed.", "enabled": true },
    { "type": "LINK",  "value": "https://modrinth.com/mod/xaeros-minimap", "reason": "Minimap mods are not allowed.", "enabled": true }
  ]
}
```

### Rule types (this is the "specify by name, id, link, or anything else" part)

| type     | `value`                                   | how it matches                                                             |
|----------|--------------------------------------------|------------------------------------------------------------------------------|
| `MODID`  | `xaerominimap`                            | exact match against the detected channel's namespace                        |
| `NAME`   | `xray`                                    | case-insensitive "contains" match against the namespace                     |
| `REGEX`  | `(?i)(freecam\|baritone)`                  | full Java regex against the namespace and the full `namespace:path` channel |
| `CHANNEL`| `xaerominimap:main`                       | exact match against a full channel id (most specific option)                |
| `LINK`   | `https://modrinth.com/mod/xaeros-minimap` | slug is pulled from the URL and matched like `NAME`                         |

Use `/modblocker inspect <player>` (see below) on someone already running the mod you want to
block to see exactly what channel namespace it registers, then write a precise `MODID` or
`CHANNEL` rule instead of guessing.

### Top-level options

- `enabled` — master on/off switch.
- `mode` — `"blacklist"` (default, kick anyone who matches a rule) or `"whitelist"` (kick
  anyone who *doesn't* match at least one rule — use carefully, since plain vanilla clients
  and no-network mods won't match anything either).
- `kickMessage` — shown on kick, `%reason%` is replaced with the matched rule's `reason`.
- `logDetections` — logs every join's detected channels to the console, useful while you're
  building your rule list.
- `requireServerResourcePack` / `resourcePackUrl` / `resourcePackSha1` /
  `resourcePackKickMessage` — if enabled, the mod writes the equivalent vanilla
  `server.properties` keys (`require-resource-pack`, `resource-pack`, `resource-pack-sha1`,
  `resource-pack-prompt`) for you on startup. **Restart the server once** after first setting
  this, since `server.properties` is only read at boot.

## Commands (requires permission level 3, i.e. server op)

- `/modblocker reload` — reload `config.json` without restarting.
- `/modblocker list` — print the currently loaded rules.
- `/modblocker inspect <player>` — show exactly which channels were detected for a connected
  player, so you can turn that into an accurate rule.

## Notes

- Detection happens the moment a player finishes joining (`ServerPlayConnectionEvents.JOIN`),
  before they can move or interact, and the connection is closed immediately on a match.
- Because detection is channel-based, a determined player who strips their mod's networking
  or renames channels could evade it — like any client-side check, this raises the bar rather
  than being unbeatable. Combine with normal server moderation/anti-cheat as usual.
